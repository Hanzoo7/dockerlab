module.exports = {
    get admin() {
        return require('./admin');
    },
    get content() {
        return require('./content');
    }
};
